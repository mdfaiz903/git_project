# hello-everyone
Hello Everyone repo for this git course.

this is the first project on github.

Thank you!
